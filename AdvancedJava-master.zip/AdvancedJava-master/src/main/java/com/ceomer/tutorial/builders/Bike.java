package com.ceomer.tutorial.builders;

import com.ceomer.tutorial.Builder;

@Builder
public class Bike {
    public String name;
    public int wheels;
    public String type;

    public Bike(String name, int wheels, String type) {
        this.name = name;
        this.wheels = wheels;
        this.type = type;
    }
    public Bike(){

    }
}
