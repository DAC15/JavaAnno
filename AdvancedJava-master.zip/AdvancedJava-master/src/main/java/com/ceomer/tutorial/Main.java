package com.ceomer.tutorial;




import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.function.Predicate;


public class Main {

    public static void main(String[] args) throws Exception {

    }
}