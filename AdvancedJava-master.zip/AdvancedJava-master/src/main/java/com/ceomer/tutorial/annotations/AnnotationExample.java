package com.ceomer.tutorial.annotations;

import com.ceomer.tutorial.Builder;

@Builder
public class AnnotationExample {

    private static final Object suppliedObject1 = new Object();
    private static final Object suppliedObject2 = new Object();




}
